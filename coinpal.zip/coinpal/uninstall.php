<?php
// 防止直接访问
if (!defined('WP_UNINSTALL_PLUGIN')) {
	exit;
}

global $wpdb;

$wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '%coinpal%'");

